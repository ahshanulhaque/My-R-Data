#------------------------------Data Visualization ---------------
# ---R packages
library(readxl)
library(haven)  
library(tidyverse)
library(expss)
library(gtsummary)
library(gt)
library(cards)
library(psych)


load('P:/abc/dat_3.Rdata')

#----Histogram 

dat_3 %>%
  ggplot(aes(x=ht)) +
  geom_histogram(
    color='black',
    fill='skyblue'
  )

#----Boxplot
dat_3 %>%
  ggplot(aes(y=ht)) +
  geom_boxplot(
    outlier.colour = 'red'
  )


#----Boxplot by a categorical variable

dat_3 %>%
  ggplot(aes(y=ht, x=smoking, fill = smoking)) +
  geom_boxplot()


#----Boxplot by two categorical variables

dat_3 %>%
  ggplot(aes(y=ht, x=smoking, fill = ses)) +
  geom_boxplot(
    outlier.colour = 'red',
    outlier.size = 2,
    notch = TRUE
  )+
  labs(
    x='Smoking Status',
    y='Body height in cm',
    fill='Socio economic status',
    title = 'Distribution of height'
  )+
  theme(
    plot.title = element_text(hjust = 0.5, size=14, face = 'bold'),
    legend.position = 'top'
  )

#  save the plot---


Plot1<- dat_3 %>%
  ggplot(aes(y=ht, x=smoking, fill = ses)) +
  geom_boxplot(
    outlier.colour = 'red',
    outlier.size = 2,
    notch = TRUE
  )+
  labs(
    x='Smoking Status',
    y='Body height in cm',
    fill='Socio economic status',
    title = 'Distribution of height'
  )+
  theme(
    plot.title = element_text(hjust = 0.5, size=14, face = 'bold'),
    legend.position = 'top'
  )

ggsave(
  'Plot1.jpeg',
  plot=Plot1,
  device = 'jpeg',
  dpi=900,
  limitsize = FALSE,
  units = 'in',
  width = 25,
  height = 11.5,
  path = 'P:/abc'
)