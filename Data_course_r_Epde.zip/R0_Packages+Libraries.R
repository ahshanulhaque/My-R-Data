#
# R Packages / Libraries
#
library(readxl)      # Excel import  
library(haven)       # Stata/SPSS/SAS import  
library(tidyverse)   # Data & plots  
library(expss)       # Labels  
library(gtsummary)   # Summary tables  
library(gt)          # Nice tables  
library(cards)       # Card outputs  
library(psych)       # Descriptive stats  
library(car)         # Regression tools  
library(geepack)     # GEE models  
library(lme4)        # Mixed models  
library(lmerTest)    # p-values for lme4  
library(broom.mixed) # Tidy mixed models  




#























library(FactoMineR)


