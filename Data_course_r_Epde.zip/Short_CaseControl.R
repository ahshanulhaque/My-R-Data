
# ---R packages
library(readxl)
library(haven)  
library(tidyverse)
library(expss)
library(gtsummary)
library(gt)
library(cards)
library(psych)

library(survival)

#---Data Import--------

mydata <- read_excel('P:/abc/case_control.xlsx')

dat_case <- mydata %>%
  mutate(
    csex = factor(csex,
                  levels = c(1,2),
                  labels = c('Male', 'Female'),
                  exclude = NA),
    medu = factor(medu,
                  levels = c(1,2,3,4),
                  labels = c("None", "Primary", "Secondary", "Higher"),
                  exclude = NA)
  ) %>%
  apply_labels(
    sid                 = "Study participant ID",
    diarr               = "Child diarrhea status",
    csex                = "Sex of child",
    cage                = "Age of child (months)",
    mage                = "Maternal age (years)",
    medu                = "Maternal education level",
    shigella       = "Shigella_EIEC",
    campy = "Campylobacter jejuni/coli",
    rotavirus           = "Rotavirus",
    ETEC    = "Enterotoxigenic E. coli"
  )

save(dat_case, file = 'P:/abc/dat_case.Rdata')



#-----------Descriptive--------

load('P:/abc/dat_case.Rdata')

Tab1 <- dat_case %>%
  select(diarr, mage, medu, campy, rotavirus, ETEC, shigella) %>%
  tbl_summary(
    missing = 'no',
    by=diarr,
    statistic = list(
      all_categorical() ~ '{n} ({p})',
      all_continuous()  ~ '{mean} ± {sd}'
    ),
    digits = list(
      all_categorical() ~ c(0,1),
      all_continuous()  ~ c(1,1)
    )
  )%>%
  bold_labels()

print(Tab1)
#

#----Simple Conditional logistic model

clogit(
  diarr ~ shigella + strata(sid),
  data = dat_case
) %>%
  tbl_regression(
    exponentiate = TRUE
  )

#----multiple Conditional logistic model

clogit(
  diarr ~ mage + medu+ campy + rotavirus + ETEC + shigella + strata(sid),
  data = dat_case
) %>%
  tbl_regression(
    exponentiate = TRUE
  )

#----Publication Ready Table---Crude Odds Ratio---

Tab2 <- dat_case %>%
  select(diarr, sid, mage, medu, campy, rotavirus, shigella) %>%
  tbl_uvregression(
    method = clogit,
    y=diarr,
    formula = "{y} ~ {x} + strata (sid)",
    exponentiate = TRUE,
    pvalue_fun =~ style_pvalue(.x, digits = 3)
  ) %>%
  modify_column_merge(
    pattern = "{estimate} ({conf.low}, {conf.high})",
    rows = !is.na(estimate)
  )%>%
  modify_header(estimate ~ "**OR (95% CI)**") %>%
  bold_labels()


print(Tab2)



#----Publication Ready Table---Adjusted Odds Ratio---

Tab3 <- clogit(
  diarr~  mage+ medu+ campy+ rotavirus+ shigella+ strata(sid),
  data = dat_case) %>%
  tbl_regression(
    exponentiate = TRUE,
    pvalue_fun =~ style_pvalue(.x, digits = 3)
  )%>%
  modify_column_merge(
    pattern = "{estimate} ({conf.low}, {conf.high})",
    rows = !is.na(estimate)
  )%>%
  modify_header(estimate ~ "**OR (95% CI)**") %>%
  bold_labels()

print(Tab3)

#----Publication Ready Table

Tab_final <- tbl_merge(
  tbls = list(Tab1, Tab2, Tab3),
  tab_spanner = c('**Descriptive**', '**Crude**', '**Adjusted**')
)

print(Tab_final)

Tab_final %>%
  as_gt()%>%
  gtsave(filename = "Tab_final.docx",
         path = 'P:/abc')


