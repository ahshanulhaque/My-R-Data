#----------------------------------Data Management Part - 3  --Variable transformation--------------------------------
# ---R packages
library(readxl)
library(haven)  
library(tidyverse)
library(expss)
library(gtsummary)
library(gt)
library(cards)
library(psych)
# -------Generate new variable

load('P:/abc/dat_1.Rdata')

dat_2 <- dat_1 %>%
  mutate(
    ht_mtr=ht/100,
    bmi=wt/ht_mtr^2
  ) %>%
  apply_labels(
    ht_mtr = "Respondent's height in meter",
    bmi    = "Respondent's body mass Index"
  )

#--------------------Recode ----

dat_3 <- dat_2 %>%
  mutate(
    bmi_cat3=case_when(
      bmi<18.5            ~1,
      bmi>=18.5 &bmi<25   ~2,
      bmi>=25             ~3,
      is.na(bmi)~NA
    ),
    bmi_cat3 = factor(bmi_cat3,
                      levels = c(1,2,3),
                      labels = c('Underweight', 'Normal weight', 'Overweight' ),
                      exclude = NA
    )
  ) %>%
  apply_labels(
    bmi_cat3="Respondent's underweight/Overweight"
  )

save(dat_3,file = 'P:/abc/dat_3.Rdata')
