
#-  --Cohort study for count outcome
#---- Poisson Regression for Count Outcome --Incidence rate ratio

library(readxl)
library(expss)
library(gtsummary)
library(gt)
library(cards)
library(psych)
library(car)

# ---Import Excel Data------------------

mydata <- read_excel('P:/abc/diar_episode.xlsx')

#-----------Value label and Variable label

dat_p <- mydata %>%
  mutate(
    infection = factor(infection,
                       levels = c(0, 1),
                       labels = c("Negative", "Positive"),
                       exclude = NA),
    urbanrural = factor(urbanrural,
                        levels = c(1, 2),
                        labels = c("Urban", "Rural"),
                        exclude = NA),
    wealth = factor(wealth,
                    levels = c(1,2,3,4,5),
                    labels = c("Poorest", "Poorer", "Middle", "Richer", "Richest"),
                    exclude = NA)
  ) %>% 
  apply_labels(
    sid	 = 	"Study ID",
    infection	 = 	"Pathogen infection",
    urbanrural	 = 	"Place of residence",
    wealth	 = 	"Wealth index",
    income	 = 	"Monthly income (Thousand)",
    dia_episode	 = 	"Number of diarrheal episode "
  )


save(dat_p, file = 'P:/abc/dat_p.Rdata')




#  -- Data analysis------Summary Table----------

load('P:/abc/dat_p.Rdata')

describe(dat_p)

dat_p %>%
  select(infection, urbanrural, wealth, income, dia_episode) %>%
  tbl_summary(
    missing = 'no',
    by = infection,
    statistic = list(
      all_categorical() ~ '{n} ({p})',
      all_continuous()  ~ '{mean}  ± {sd}' 
    ),
    digits = list(
      all_categorical() ~ c(0,2),
      all_continuous()  ~ c(2,2)
    )
  ) %>%
  add_overall(last=TRUE) %>%
  bold_labels()


# --------P-value-----



Tab1 <- dat_p %>%
  select(infection, urbanrural, wealth, income, dia_episode) %>%
  tbl_summary(
    missing = 'no',
    by = infection,
    statistic = list(
      all_categorical() ~ '{n} ({p})',
      all_continuous()  ~ '{mean}  ± {sd}' 
    ),
    digits = list(
      all_categorical() ~ c(0,2),
      all_continuous()  ~ c(2,2)
    )
  ) %>%
  add_overall(last=TRUE) %>%
  bold_labels() %>%
  add_p(
    test=list(
      all_categorical() ~ 'chisq.test',
      all_continuous()  ~ 't.test'
    ),
    pvalue_fun=~ style_pvalue(.x, digits = 3)
  )

print(Tab1)


Tab1 %>%
  as_gt() %>%
  gtsave(filename = 'Table1.docx',
         path = 'P:/abc')
#


#----------Simple Poisson regression

glm(
  dia_episode ~ infection,
  data = dat_p,
  family = poisson(link = 'log')
) %>%
  tbl_regression(
    exponentiate = TRUE
  )


#-----------Multiple Poisson Regression--------

glm(
  dia_episode ~ infection + urbanrural + wealth + income,
  data = dat_p,
  family = poisson(link = 'log')
) %>%
  tbl_regression(
    exponentiate = TRUE
  )


#---------Publication Ready Table

#--------Unadjusted IRR

PR_1 <- dat_p %>%
  select(dia_episode, infection, urbanrural, wealth, income) %>%
  tbl_uvregression(
    method = glm,
    y=dia_episode,
    method.args = list(family = poisson(link = 'log')),
    exponentiate = TRUE,
    pvalue_fun =~ style_pvalue(.x, digits = 3)
  ) %>%
  modify_column_merge(
    pattern = '{estimate} ({conf.low}, {conf.high})',
    rows = !is.na(estimate)
  ) %>%
  modify_header( estimate ~ '**IRR (95%CI)**') %>%
  bold_labels()

print(PR_1)


#

#---Adjusted IRR-------------

PR_2 <- glm(
  dia_episode~  infection + urbanrural + wealth + income,
  data = dat_p,
  family = poisson(link = 'log')
) %>%
  tbl_regression(
    exponentiate = TRUE,
    pvalue_fun =~ style_pvalue(.x, digits = 3)
  ) %>%
modify_column_merge(
    pattern = '{estimate} ({conf.low}, {conf.high})',
    rows = !is.na(estimate)
  ) %>%
  modify_header( estimate ~ '**IRR (95%CI)**') %>%
  bold_labels()


print(PR_2)



Final_tab <- tbl_merge(
  tbls = list(PR_1, PR_2),
  tab_spanner = c('**Unadjusted**', '**Adjusted**')
)


print(Final_tab)

#

Final_tab %>%
  as_gt() %>%
  gtsave(filename = 'Table2.docx',
         path = 'P:/abc')










