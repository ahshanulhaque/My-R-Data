# ----------------- Logistic Regression----------------
# ---R packages
library(readxl)
library(haven)  
library(tidyverse)
library(expss)
library(gtsummary)
library(gt)
library(cards)
library(psych)


load('P:/abc/New folder/dat_3.Rdata')

#---Simple Logit

glm(
  disease ~ smoking, 
  data = dat_3, 
  family = binomial(link = 'logit')
  ) %>%
  tbl_regression(
    exponentiate = TRUE
  )

#---multiple Logit

glm(
  disease ~ smoking + urbanrural + ses+ bmi_cat3, 
  data = dat_3, 
  family = binomial(link = 'logit')) %>%
  tbl_regression(
    exponentiate = TRUE
  )

#-------------Change the reference-----------------


dat_3 <- dat_3 %>%
  mutate(
    urbanrural = relevel(urbanrural, ref = 'Urban'),
    ses = relevel(ses, ref = 'Rich')
  ) %>%
  apply_labels(
    urbanrural = "Place of residence",
    ses = 'Socio economic status'
  )



glm(
  disease ~ smoking + urbanrural + ses+ bmi_cat3, 
  data = dat_3, 
  family = binomial(link = 'logit')) %>%
  tbl_regression(
    exponentiate = TRUE
  )





#












#


#--------------Unadjusted--Odds Ratio----------

# load('P:/abc/New folder/dat_3.Rdata')




OR1 <- dat_3 %>%
  select(disease, smoking, urbanrural, ses, bmi_cat3, bicycle, motor)%>%
  tbl_uvregression(
    method = glm,
    y=disease,
    method.args = list(family=binomial(link = 'logit')),
    exponentiate = TRUE,
    pvalue_fun =~ style_pvalue(.x, digits = 3)
  ) %>%
  modify_column_merge(
    pattern = '{estimate} ({conf.low}, {conf.high})',
    rows = !is.na(estimate)
  ) %>%
  modify_header(estimate ~ '**OR (95% CI)**') %>%
  bold_labels()


print(OR1)


#--------------Adjusted--Odds Ratio----------
OR2 <- glm(disease~ smoking + urbanrural + ses + bmi_cat3 + bicycle + motor,
           data = dat_3,
           family = binomial(link = 'logit'))%>%
  tbl_regression(
    exponentiate = TRUE,
    pvalue_fun =~ style_pvalue(.x, digits = 3)
  )%>%
  modify_column_merge(
    pattern = '{estimate} ({conf.low}, {conf.high})',
    rows = !is.na(estimate)
  ) %>%
  modify_header(estimate ~ '**OR (95% CI)**') %>%
  bold_labels()

print(OR2)



#--Publication-ready tables in R--------

Tab_2 <- tbl_merge(
  tbls = list(OR1, OR2),
  tab_spanner = c('**Unadjusted**', '**Adjusted**')
)

print(Tab_2)


#---Save The Table

Tab_2 %>%
  as_gt()%>%
  gtsave(filename = 'Table_2.docx',
         path = 'P:/abc')

