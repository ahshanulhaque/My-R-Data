# ------------------------ Data Analysis
# ---R packages
library(readxl)
library(haven)  
library(tidyverse)
library(expss)
library(gtsummary)
library(gt)
library(cards)
library(psych)

load('P:/abc/dat_3.Rdata')


dat_3 %>%
  tbl_summary()

#----- Univariate

dat_3 %>%
  select(disease, smoking, urbanrural, ses, ht,wt, bmi, bmi_cat3, bicycle, motor) %>%
  tbl_summary()



#----- Bi-variate

dat_3 %>%
  select(disease, smoking, urbanrural, ses, ht,wt, bmi, bmi_cat3, bicycle, motor) %>%
  tbl_summary(
    missing = 'no',
    by=smoking
  )


#----- Bi-variate---Statistic

dat_3 %>%
  select(disease, smoking, urbanrural, ses, ht,wt, bmi, bmi_cat3, bicycle, motor) %>%
  tbl_summary(
    missing = 'no',
    by=smoking,
    statistic = list(
      all_categorical() ~ '{n} ({p})',
      all_continuous()  ~ '{mean} ± {sd}'
    ),
    digits = list(
      all_categorical() ~ c(0,1),
      all_continuous()  ~c(1,1,1)
    )
  ) %>%
  add_overall(last=TRUE) %>%
  bold_labels()


# --- Inferential ---Statistic--p-value


dat_3 %>%
  select(disease, smoking, urbanrural, ses, ht,wt, bmi, bmi_cat3, bicycle, motor) %>%
  tbl_summary(
    missing = 'no',
    by=smoking,
    statistic = list(
      all_categorical() ~ '{n} ({p})',
      all_continuous()  ~ '{mean} ± {sd}'
    ),
    digits = list(
      all_categorical() ~ c(0,1),
      all_continuous()  ~c(1,1,1)
    )
  ) %>%
  add_overall(last=TRUE) %>%
  bold_labels() %>%
  add_p(
    test=list(
      all_categorical() ~ 'chisq.test',
      all_continuous()  ~ 't.test'
    ),
    pvalue_fun =~ style_pvalue(.x, digits = 3)
  )


#  Save the Table as MS Word Format


Tab_1 <- dat_3 %>%
  select(disease, smoking, urbanrural, ses, ht,wt, bmi, bmi_cat3, bicycle, motor) %>%
  tbl_summary(
    missing = 'no',
    by=smoking,
    statistic = list(
      all_categorical() ~ '{n} ({p})',
      all_continuous()  ~ '{mean} ± {sd}'
    ),
    digits = list(
      all_categorical() ~ c(0,1),
      all_continuous()  ~c(1,1,1)
    )
  ) %>%
  add_overall(last=TRUE) %>%
  bold_labels() %>%
  add_p(
    test=list(
      all_categorical() ~ 'chisq.test',
      all_continuous()  ~ 't.test'
    ),
    pvalue_fun =~ style_pvalue(.x, digits = 3)
  )

#  
Tab_1 %>%
  as_gt() %>%
  gtsave(filename = 'Table_1.docx',
         path = 'P:/abc')


