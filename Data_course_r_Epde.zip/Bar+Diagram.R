
#-----------Data Visualization -------Bar diagram--------
  
library(readxl)
library(tidyverse)
library(gtsummary)
library(RColorBrewer)

load('P:/abc/dat_3.Rdata')


#--- Bar diagram ---Factor / categorical variables----- 

A1 <- dat_3 %>%
  select(bmi_cat3) %>%
  drop_na() %>%
  count(bmi_cat3) %>%
  mutate(
    p = n/sum(n)*100
  )

A1 %>%
  ggplot(aes(x=bmi_cat3, y=p)) +
  geom_bar(
    stat = 'identity',
    fill= 'skyblue'
  )







#---------Modification

A1 <- dat_3 %>%
  select(bmi_cat3) %>%
  drop_na() %>%
  count(bmi_cat3) %>%
  mutate(
    p = n/sum(n)*100
  )

A1 %>%
  ggplot(aes(x=bmi_cat3, y=p)) +
  geom_bar(
    stat = 'identity',
    fill= 'skyblue',
    width = 0.5
  ) +
  labs(
    x= "Respondent's underweight/overweight",
    y = "Percentage"
  )+
  theme(
    axis.title = element_text(
      hjust = 0.5,
      size = 12,
      face = "bold"
    )
  ) +
  geom_text(
    aes(label = paste0(round(p,1))),
    position = position_stack(vjust = 1.05)
  )


#----------Bar diagram by a group variable

A2 <- dat_3 %>%
  select(bmi_cat3, ses) %>%
  drop_na() %>%
  count(bmi_cat3, ses) %>%
  group_by(ses) %>%
  mutate(
    p = n/sum(n)*100
  ) %>%
  ungroup()


A2 %>%
  ggplot(aes(x=bmi_cat3, y=p, fill = ses)) +
  geom_bar(
    stat = 'identity',
    position = position_dodge(width = 0.7),
    width = 0.6
  ) +
  labs(
    x = "Respondent's Underweigt/overweight",
    y = "Percentage",
    fill= "Socio-economic status"
  )+
  theme(
    axis.title = element_text(
      hjust = 0.5,
      size = 12
    )
  )+
  geom_text(
    aes(label = paste0(round(p,1))),
    position = position_dodge(width = 0.7),
    size = 4,
    vjust = -0.5
  )



#











