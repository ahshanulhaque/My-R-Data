#----------------------------------Data Management Part - 2  -----data labeling----------------------------

# ---R packages
library(readxl)
library(haven)  
library(tidyverse)
library(expss)
library(gtsummary)
library(gt)
library(cards)
library(psych)

mydata<-read_excel('P:/abc/data2.xlsx')


dat_1 <- mydata %>%     #--------Value labels for categorical variables  ---------
mutate(
  smoking = factor(smoking,
                   levels = c(0,1),
                   labels = c("Non-smoker", "Smoker"),
                   exclude = NA),
  urbanrural = factor(urbanrural,
                      levels = c(0,1),
                      labels = c("Rural", "Urban"),
                      exclude = NA),
  ses = factor(ses,
               levels = c(1,2,3),
               labels = c("Poor", "Middle", "Rich"),
               exclude = NA)
) %>%
  apply_labels(                                   #---Variable Label--------------
          main_id    = "Study ID",
          disease    = "Disease Status",
          smoking    = "Smoking Status",
          urbanrural = "Residence Type",
          ses        = "Socioeconomic Status",
          ht	 = 	 "Body Height in cm",
          wt	 = 	 "Body Weight in kg",
          bicycle	 =	"Household has: bicycle",
          motor	 =	"Household has: motorcycle"
  )

save(dat_1,file = 'P:/abc/dat_1.Rdata')

