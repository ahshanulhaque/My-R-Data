# ----------------- Log-Binomial or Poisson Regression---Risk Ratio------
# ---R packages
library(readxl)
library(tidyverse)
library(expss)
library(gtsummary)
library(gt)
library(cards)

load('P:/abc/dat_3.Rdata')

#---Simple Log-Binomial-------------

glm(disease ~ smoking, 
    data = dat_3, 
    family = binomial(link = 'log')) %>%
  tbl_regression(
    exponentiate = TRUE
  )






#---Multiple Log-Binomial-------------

glm(disease ~ smoking + urbanrural , 
    data = dat_3, 
    family = binomial(link = 'log')) %>%
  tbl_regression(
    exponentiate = TRUE
  )





#---Multiple Poisson-------------

glm(disease ~ smoking + urbanrural+ses , 
    data = dat_3, 
    family = poisson(link = 'log')) %>%
  tbl_regression(
    exponentiate = TRUE
  )






#--------Modified Poisson Regression
library(readxl)
library(haven)  
library(tidyverse)
library(expss)
library(gtsummary)
library(gt)
library(cards)
library(psych)

#--------------Unadjusted--Risk Ratio----------

poi_1 <- dat_3 %>%
  select(disease, smoking, urbanrural, ses, bmi_cat3, bicycle, motor)%>%
  tbl_uvregression(
    method = glm,
    y=disease,
    method.args = list(family=poisson(link = 'log')),
    exponentiate = TRUE,
    pvalue_fun =~ style_pvalue(.x, digits = 3)
  ) %>%
  modify_column_merge(
    pattern = '{estimate} ({conf.low}, {conf.high})',
    rows = !is.na(estimate)
  ) %>%
  modify_header(estimate ~ '**RR (95% CI)**') %>%
  bold_labels()


print(poi_1)


#--------------Adjusted--Risk Ratio----------


poi_2 <- glm(disease~ smoking + urbanrural + ses + bmi_cat3 + bicycle + motor,
             data = dat_3,
             family = poisson(link = 'log'))%>%
  tbl_regression(
    exponentiate = TRUE,
    pvalue_fun =~ style_pvalue(.x, digits = 3)
  )%>%
  modify_column_merge(
    pattern = '{estimate} ({conf.low}, {conf.high})',
    rows = !is.na(estimate)
  ) %>%
  modify_header(estimate ~ '**RR (95% CI)**') %>%
  bold_labels()

print(poi_2)



#--Publication-ready tables in R--------

Tab_3 <- tbl_merge(
  tbls = list(poi_1, poi_2),
  tab_spanner = c('**Unadjusted**', '**Adjusted**')
)

print(Tab_3)


#---Save The Table

Tab_3 %>%
  as_gt()%>%
  gtsave(filename = 'Table_3.docx',
         path = 'P:/abc')