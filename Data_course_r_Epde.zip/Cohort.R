
#----------Cohort data analysis------------

# ---R packages
library(readxl)
library(tidyverse)
library(expss)
library(gtsummary)
library(gt)
library(cards)
library(psych)
library(car)

dat_10 <- read_excel('P:/abc/Cohort_hemo.xlsx')


dat_cohort <- dat_10 %>%
  mutate(
    food_insec = factor(food_insec,
                        levels = c(0,1),
                        labels = c("Secure", "Insecure"),
                        exclude = NA),
    
    edu = factor(edu,
                 levels = c(1, 2, 3),
                 labels = c("No formal education", "Primary", "Secondary/Higher"),
                 exclude = NA),
    
    anc2 = factor(anc2,
                  levels = c(1, 2),
                  labels = c("At least 4", "Less than 4"),
                  exclude = NA),
    
    csex = factor(csex,
                  levels = c(1, 2),
                  labels = c("Male", "Female"),
                  exclude = NA),
    
    ) %>%
  apply_labels(
    main_id    = "Study ID",
    food_insec = "Food insecurity status of household",
    edu        = "Maternal education",
    anc2       = "Mother received at least 4 ANC visits",
    mbmi       = "Maternal BMI",
    csex      = "Sex of child",
    hemo_0     = "Hemoglobin level at enrollment",
    anemia_0   = "Anemia at enrollment",
    hemo       = "Hemoglobin (g/dL)",
    anemia     = "Childhood anemia",
    protein    = "Number of days consuming protein-rich foods"
  ) %>%
  filter(anemia_0 != 1) %>%
  select(food_insec, edu, anc2, mbmi, csex, protein, hemo, anemia)


dat_cohort %>%
  tbl_summary()



#---Save the Data ---R Format

save(dat_cohort, file = 'P:/abc/dat_cohort.Rdata')


load('P:/abc/dat_cohort.Rdata')


#------------data Summary---------------

dat_cohort %>%
  select(food_insec, edu, anc2, mbmi, csex,  protein, hemo, anemia) %>%
  tbl_summary(
    missing = 'no',
    by= food_insec,
    statistic = list(
      all_categorical() ~'{n} ({p})',
      all_continuous() ~'{mean} ± {sd}'
    ),
    digits = list(
      all_categorical() ~c(0,2),
      all_continuous() ~c(2,2,2)
    )
  ) %>%
  bold_labels() %>%
  add_overall(last=TRUE) %>%
  add_p(
    test=list(
      all_categorical() ~ 'chisq.test',
      all_continuous() ~ 't.test'
    ),
    pvalue_fun =~ style_pvalue(.x, digits = 3)
  )



#-----Risk Ratio estimation-----------

#---Simple log binomial regression---

glm(
  anemia ~ food_insec, 
  data = dat_cohort,
  family = binomial(link = 'log')
  ) %>%
  tbl_regression(
    exponentiate = TRUE
  )




#---Multiple log binomial regression---

glm(
  anemia ~ food_insec + edu, 
  data = dat_cohort,
  family = binomial(link = 'log')
) %>%
  tbl_regression(
    exponentiate = TRUE
  )


#----Modified Poisson Regression-----

glm(
  anemia ~ food_insec, 
  data = dat_cohort,
  family = poisson(link = 'log')
) %>%
  tbl_regression(
    exponentiate = TRUE
  )


#----Modified multiple Poisson Regression-----

glm(
  anemia ~ food_insec+ edu+ anc2+ mbmi+ csex+  protein, 
  data = dat_cohort,
  family = poisson(link = 'log')
) %>%
  tbl_regression(
    exponentiate = TRUE
  )



# ---Publication-ready tables --Risk Ratio------------

#--Unadjusted Risk Ratio

RR1 <- dat_cohort %>%
  select(anemia, food_insec, edu, anc2, csex, protein) %>%
  tbl_uvregression(
    method = glm,
    y=anemia,
    method.args = list(family=poisson(link = 'log')),
    exponentiate = TRUE,
    pvalue_fun =~ style_pvalue(.x, digits = 3)
  ) %>%
  modify_column_merge(
    pattern = '{estimate} ({conf.low}, {conf.high})',
    rows = !is.na(estimate)
  )%>%
  modify_header(estimate ~'**RR (95% CI)**') %>%
  bold_labels()




print(RR1)



#-----Adjusted---------------

RR2 <- glm(
  anemia~ food_insec+ edu+ anc2+ csex+ protein,
  data = dat_cohort,
  family = poisson(link='log')
)%>%
  tbl_regression(
    exponentiate = TRUE,
    pvalue_fun =~ style_pvalue(.x, digits = 3)
  )%>%
  modify_column_merge(
    pattern = '{estimate} ({conf.low}, {conf.high})',
    rows = !is.na(estimate)
  )%>%
  modify_header(estimate ~'**RR (95% CI)**') %>%
  bold_labels()


print(RR2)


Tab_RR <- tbl_merge(
  tbls = list(RR1, RR2),
  tab_spanner = c('**Unadjusted**', '**Adjusted**')
)

print(Tab_RR)

#---Save the Table

Tab_RR %>%
  as_gt() %>%
  gtsave(filename = 'Table2.docx',
         path = 'P:/abc')


