
#--Quick Start: Create Graph and Table in R
#---- Load Required Packages

library(readxl)      # reading Excel data
library(tidyverse)   # data management and ggplot
library(gtsummary)   # summary tables

AB <- read_excel("P:/abc/hospital.xlsx")

#----A box plot----

ggplot(AB, aes(y=hemo, x= gender, fill=hosp)) +
  geom_boxplot()

#---A summary table----

tbl_summary(AB, by =gender)




