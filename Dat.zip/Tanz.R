#-----GIS Spatial Analysis in Rstudio--Tanzania
library(readxl)     
library(tidyverse)   
library(sf)
library(viridis)

g_map <- st_read("Regions.shp")

g_map <- g_map %>%
  mutate(
    Region_Cod = as.numeric(Region_Cod)
  )

dat <- read_excel("dat_nutri.xlsx")

dat_s <- dat %>% 
  select(Region_Cod, stunting) %>%
  group_by(Region_Cod) %>%
  summarise(
    p = mean(stunting) * 100,
    .groups = 'drop'
  )


map_data <- g_map %>%
  left_join(dat_s, by =c('Region_Cod' = 'Region_Cod'))


ggplot(map_data) +
  geom_sf(aes(fill = p), color = "grey70", size = 0.2) +
  geom_sf_text(
    aes(label = round(p, 1)),   # round as needed
    size = 3,
    color = "black"
  ) +
  scale_fill_viridis(
    option = "plasma",
    direction = -1,
    name = "Stunting (%)",
    na.value = "grey90"
  ) +
  labs(
    title = "Childhod Stunting by Region: Tanzania",
    subtitle = "Percentage of children under age five",
    caption = "Source: DHS"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(face = "bold", size = 14),
    legend.position = "right"
  ) +
  coord_sf(expand = FALSE)





#------------





ggplot(map_data) +
  geom_sf(aes(fill = p), color = "grey70", size = 0.2) +
  scale_fill_viridis(
    option = "plasma",
    direction = -1,
    name = "Stunting (%)",
    na.value = "grey90"
  ) +
  labs(
    title = "Child Stunting by Region",
    subtitle = "Percentage of children under age five",
    caption = "Source: DHS"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(face = "bold", size = 14),
    legend.position = "right"
  ) +
  coord_sf(expand = FALSE)










